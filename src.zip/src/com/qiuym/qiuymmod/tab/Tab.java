package com.qiuym.qiuymmod.tab;

import com.qiuym.qiuymmod.QiuymModItem;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public class Tab {
    public CreativeModeTab output() {
        return CreativeModeTab.m_257815_(net.minecraft.world.item.CreativeModeTab.Row.BOTTOM, 5)
            .m_257941_(net.minecraft.network.chat.Component.m_237113_("§5§lQiuym Mod"))
            .m_257737_(() -> new ItemStack(QiuymModItem.SICKLE.get()))
            .m_257501_((parameters, output) -> {
                output.m_246342_(new ItemStack(QiuymModItem.SICKLE.get()));
                output.m_246342_(new ItemStack(QiuymModItem.SILICON_PICKAXE.get()));
            })
            .m_257652_();
    }
}