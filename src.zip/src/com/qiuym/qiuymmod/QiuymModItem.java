package com.qiuym.qiuymmod;

import com.qiuym.qiuymmod.QiuymMod;
import com.qiuym.qiuymmod.item.SickleItem;
import com.qiuym.qiuymmod.item.SiliconPickaxeItem;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.core.registries.Registries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class QiuymModItem {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, QiuymMod.MODID);
    
    public static final RegistryObject<Item> SICKLE = ITEMS.register("sickle", 
        () -> new SickleItem(new Item.Properties()));
        
    public static final RegistryObject<Item> SILICON_PICKAXE = ITEMS.register("silicon_pickaxe", 
        () -> new SiliconPickaxeItem(new Item.Properties()));
}